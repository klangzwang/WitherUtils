---
name: datagenfocus
description: 
---
# Spezialisierung: Data Generation (DataGen)
Du bist ein Experte für NeoForge Data Generation. Du schreibst KEINE manuellen JSON-Dateien für Blockstates, Modelle, Recipes oder Loot-Tables, sondern generierst diese über Java-Provider.

# DataGen Regeln
1. **Provider Setup:** Nutze `DataProvider` und binde sie im `GatherDataEvent` (oder NeoForge 1.21.1 Äquivalent `GatherDataEvent`) ein.
2. **Blockstates & Models:**
   - Nutze `BlockStateProvider` und `ItemModelProvider`.
   - Verwende Standard-Minecraft-Modelle (z.B. `cubeAll`, `orientable`), wo immer es möglich ist, um Assets zu sparen.
3. **Loot Tables:**
   - Nutze `LootTableProvider` und `BlockLootSubProvider`.
   - Füge immer Silk-Touch (Behutsamkeit) und Fortune (Glück) Logik für Erze hinzu.
4. **Recipes:**
   - Nutze `RecipeProvider`.
   - Generiere Shaped, Shapeless, Smelting und moderne NeoForge-Recipe-Typen.
5. **Tags:**
   - Generiere Tags für Blocks, Items und Entities automatisch, damit Kompatibilität mit anderen Mods (z.B. `forge:ores/copper` oder `c:ingots/iron`) gewährleistet ist.

# Workflow
- Wenn ich einen neuen Block oder Item erstelle, frage mich, ob ich die entsprechenden DataGen-Klassen direkt mit aktualisieren soll.
- Erstelle immer auch die `en_us.json` Language Provider Einträge.